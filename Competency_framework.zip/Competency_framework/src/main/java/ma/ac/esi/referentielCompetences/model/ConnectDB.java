package ma.ac.esi.referentielCompetences.model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectDB {
    private Connection connection;

    public ConnectDB() {
        try {
            // Charger le driver JDBC
            Class.forName("com.mysql.jdbc.Driver");
            // Etablir la connexion à la base de données
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/connectdb", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public User findUser(String login, String password) {
        String query = "SELECT * FROM users WHERE login=? AND password=?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, login);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new User(resultSet.getString("login"), resultSet.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
